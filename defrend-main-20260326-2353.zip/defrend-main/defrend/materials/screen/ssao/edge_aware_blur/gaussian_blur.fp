#version 420
#extension GL_ARB_shading_language_include : require

#include "/defrend/include/lighting_functions.glsl"

precision highp float;

in vec2 var_texcoord0;

uniform sampler2D color_sampler;
uniform sampler2D depth_buffer;
uniform sampler2D normal_sampler;

uniform ssao_blur_horizontal_fp {
	vec4 params;
	vec4 frustum_terms;
	vec4 delta;
};

#define RADIUS 5

float weight[RADIUS] = {
	0.240841295721373,
	0.20116755999375591,
	0.11723004402070096,
	0.047662179108871855,
	0.013519569015984728
};

float	depth_threshold = params.y;
float	normal_threshold = params.z;
vec2	resolution	= textureSize(color_sampler, 0);

layout(location = 0) out vec4 fragColor;

void main() {
	vec2 d = delta.xy / resolution;

	float result = texture(color_sampler, var_texcoord0).r * weight[0];
	float depth = texture(depth_buffer, var_texcoord0).r;
	float z = linearizeDepth(depth, frustum_terms.xyz);
	vec3  normal = texture(normal_sampler, var_texcoord0).xyz * 2.0 - 1.0;
	float total_weight = weight[0];

	for (int i = 1; i < RADIUS; ++i) {
		vec2 d_i = d * i;

		vec2 offset_l = var_texcoord0 - d_i;
		float depth_l = texture(depth_buffer, var_texcoord0 - d_i).r;
		float z_l = linearizeDepth(depth_l, frustum_terms.xyz);
		vec3 normal_l = texture(normal_sampler, var_texcoord0 - d_i).xyz * 2.0 - 1.0;
		float sample_l = texture(color_sampler, var_texcoord0 - d_i).r;
		float weight_l = step(abs(z - z_l), depth_threshold) * step(normal_threshold, dot(normal, normal_l)) * weight[i];
		result += sample_l * weight_l;
		total_weight += weight_l;

		vec2 offset_r = var_texcoord0 + d_i;
		float depth_r = texture(depth_buffer, var_texcoord0 + d_i).r;
		float z_r = linearizeDepth(depth_r, frustum_terms.xyz);
		vec3 normal_r = texture(normal_sampler, var_texcoord0 + d_i).xyz * 2.0 - 1.0;
		float sample_r = texture(color_sampler, var_texcoord0 + d_i).r;
		float weight_r = step(abs(z - z_r), depth_threshold) * step(normal_threshold, dot(normal, normal_r)) * weight[i];
		result += sample_r * weight_r;
		total_weight += weight_r;
	}
	result /= total_weight;
	fragColor = vec4(vec3(result), 1.0);
}
