#version 420
#extension GL_ARB_shading_language_include : require

#include "/defrend/include/lighting_functions.glsl"

precision highp float;

in vec2 var_texcoord0;

uniform sampler2D color_sampler;
uniform sampler2D depth_buffer;

uniform ssao_blur_depth_only_fp {
	vec4 params;
	vec4 frustum_terms;
	vec4 delta;
};

float	radius = params.x;
float	depth_threshold = params.y;
vec2	resolution	= textureSize(color_sampler, 0);

layout(location = 0) out vec4 fragColor;

void main() {

	vec2 d = delta.xy / resolution;

	float result = texture(color_sampler, var_texcoord0).r;
	float depth = texture(depth_buffer, var_texcoord0).r;
	float z = linearizeDepth(depth, frustum_terms.xyz);
	float total_weight = 1;

	for (int i = 1; i < radius; ++i) {
		vec2 d_i = d * i;

		vec2 offset_l = var_texcoord0 - d_i;
		float depth_l = texture(depth_buffer, var_texcoord0 - d_i).r;
		float z_l = linearizeDepth(depth_l, frustum_terms.xyz);
		float sample_l = texture(color_sampler, var_texcoord0 - d_i).r;
		float weight_l = step(abs(z - z_l), depth_threshold);
		result += sample_l * weight_l;
		total_weight += weight_l;

		vec2 offset_r = var_texcoord0 + d_i;
		float depth_r = texture(depth_buffer, var_texcoord0 + d_i).r;
		float z_r = linearizeDepth(depth_r, frustum_terms.xyz);
		float sample_r = texture(color_sampler, var_texcoord0 + d_i).r;
		float weight_r = step(abs(z - z_r), depth_threshold);
		result += sample_r * weight_r;
		total_weight += weight_r;
	}
	result /= total_weight;
	fragColor = vec4(vec3(result), 1.0);
}
